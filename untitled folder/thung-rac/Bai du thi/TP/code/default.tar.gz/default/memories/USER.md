User is preparing a Raspberry Pi Zero 2 W deployment (DietPi Trixie ARM64) for a Vietnamese voice/camera client and values a concrete pre-deployment review with exact file-level fixes and verified checks.
§
User’s audio design: MP3 must play through MAX98357A; WAV playback goes through Bluetooth headset MAC 41:42:1B:2D:3E:26; microphone capture must remain SCO CVSD mono 8 kHz, never mSBC/wideband.
§
For Raspberry Pi deployment transfers, user prefers ZIP/unzip instead of tar because tar archives may include macOS metadata/files.
§
User thống nhất: “agy” là viết tắt của “antigravity-cli”; áp dụng cho mọi project và mọi phiên làm việc của Hermes.