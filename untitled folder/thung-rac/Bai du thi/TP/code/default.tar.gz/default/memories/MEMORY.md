Typst theme creation and compilation involves:
1. Defining colors, fonts, and basic properties in a dictionary (e.g., `theme.lesson_plan`).
2. Creating helper functions (e.g., `make_section`, `make_table`) that directly construct Typst elements using these properties.
3. Avoiding direct use of CSS-like functions (e.g., `linear-gradient`) as they are not natively supported.
4. Correctly applying properties like `align`, `stroke`, `padding`, `fill` to elements (e.g., `table`, `text`, `block`).
5. Ensuring no duplicate arguments are passed to Typst elements.
6. Using `set` only within code/content blocks, not directly in dictionary assignments for style definitions.
7. Compiling `.typ` files using `typst compile <filename.typ>`.
§
Pi Zero 2 W project microphone requirement: Bluetooth SCO capture must use CVSD at 8 kHz mono; do not configure mSBC/wideband speech.
§
Pi Zero 2 W project now uses a play-audio script design: MP3 output should go to MAX98357A, while WAV audio is routed to Bluetooth headset MAC 41:42:1B:2D:3E:26.
§
For the Pi Zero 2 W project, Tailscale is already authenticated and working successfully; do not treat Tailscale setup/login as a current deployment blocker.